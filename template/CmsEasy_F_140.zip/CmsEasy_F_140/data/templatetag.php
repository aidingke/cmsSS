<?php return array (
  1 => 
  array (
    'id' => '1',
    'name' => '首页第一行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '1',
      'tagtemplate' => 'tag_category-title.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  2 => 
  array (
    'id' => 2,
    'name' => '首页第一行栏目图片说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '1',
      'tagtemplate' => 'tag_category_lanmushuoming.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  3 => 
  array (
    'id' => '3',
    'name' => '首页第二行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '27',
      'tagtemplate' => 'tag_category-title.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  4 => 
  array (
    'id' => 4,
    'name' => '首页第二行子栏目一',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '28',
      'tagtemplate' => 'tag_category_lanmushuoming2.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  5 => 
  array (
    'id' => 5,
    'name' => '首页第二行子栏目二',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '29',
      'tagtemplate' => 'tag_category_lanmushuoming2.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  6 => 
  array (
    'id' => 6,
    'name' => '首页第二行子栏目三',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '30',
      'tagtemplate' => 'tag_category_lanmushuoming2.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  7 => 
  array (
    'id' => 7,
    'name' => '首页第二行子栏目四',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '31',
      'tagtemplate' => 'tag_category_lanmushuoming2.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  8 => 
  array (
    'id' => '8',
    'name' => '首页第三行栏目说明更多',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'tagtemplate' => 'tag_category_lanmushuoming3.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  9 => 
  array (
    'id' => '9',
    'name' => '首页第三行左侧栏目列表6条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '13',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '16',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '6',
      'tagtemplate' => 'tag_content.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  10 => 
  array (
    'id' => '10',
    'name' => '首页第三行右侧图文说明3条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '14',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '20',
      'introduce_length' => '100',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '3',
      'tagtemplate' => 'tag_content_dl_dt_dd.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  11 => 
  array (
    'id' => '11',
    'name' => '首页第五行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '3',
      'tagtemplate' => 'tag_category-title.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  12 => 
  array (
    'id' => '12',
    'name' => '首页第五行栏目图片8条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '3',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '6',
      'introduce_length' => '40',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '8',
      'tagtemplate' => 'tag_content_i_pic1.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  13 => 
  array (
    'id' => '13',
    'name' => '首页第六行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '5',
      'tagtemplate' => 'tag_category-title.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  14 => 
  array (
    'id' => 14,
    'name' => '首页第六行栏目说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '5',
      'tagtemplate' => 'tag_category_lanmushuoming4.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  15 => 
  array (
    'id' => '15',
    'name' => '首页第六行图片列表',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '14',
      'tagtemplate' => 'tag_category-index-6-pic.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  16 => 
  array (
    'id' => '16',
    'name' => '页底栏目一',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '1',
      'tagtemplate' => 'tag_category-foot-cat-list.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  17 => 
  array (
    'id' => '17',
    'name' => '页底栏目二',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '3',
      'tagtemplate' => 'tag_category-foot-cat-list.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  18 => 
  array (
    'id' => '18',
    'name' => '页底栏目三',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'tagtemplate' => 'tag_category-foot-cat-list.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  19 => 
  array (
    'id' => '19',
    'name' => '内容页底图文产品三条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '3',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '20',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '3',
      'thumb' => 'on',
      'attr1' => '0',
      'tagtemplate' => 'tag_content-content-bottom.html',
      'submit' => '提交',
    ),
  ),
  20 => 
  array (
    'id' => '20',
    'name' => '内页右侧栏目名称',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'tagtemplate' => 'tag_category-index-title.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  21 => 
  array (
    'id' => '21',
    'name' => '内页右侧内容列表',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '20',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '10',
      'attr1' => '0',
      'tagtemplate' => 'tag_content.html',
      'submit' => '提交',
    ),
  ),
  22 => 
  array (
    'id' => '22',
    'name' => '首页第三行右侧栏目列表4条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '16',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '4',
      'tagtemplate' => 'tag_content_date.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
);