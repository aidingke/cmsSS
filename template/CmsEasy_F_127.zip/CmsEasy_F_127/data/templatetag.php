<?php return array (
  
  18 => 
  array (
    'id' => '18',
    'name' => '内页右侧栏目名称',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'tagtemplate' => 'tag_category-index-title.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  19 => 
  array (
    'id' => '19',
    'name' => '内页右侧内容列表',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '20',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '10',
      'attr1' => '0',
      'tagtemplate' => 'tag_content.html',
      'submit' => '提交',
    ),
  ),
  23 => 
  array (
    'id' => 23,
    'name' => '首页第一行图片滚动',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '3',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '12',
      'introduce_length' => '50',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '12',
      'tagtemplate' => 'tag_content_i_pic1.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  24 => 
  array (
    'id' => '24',
    'name' => '首页第二行栏目说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '1',
      'tagtemplate' => 'tag_category_lanmushuoming.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  25 => 
  array (
    'id' => '25',
    'name' => '首页第三行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '18',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  26 => 
  array (
    'id' => '26',
    'name' => '首页第三行栏目图片6条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '18',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '6',
      'introduce_length' => '50',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '6',
      'tagtemplate' => 'tag_content_i_pic2.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  27 => 
  array (
    'id' => 27,
    'name' => '首页第四行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '19',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  28 => 
  array (
    'id' => '28',
    'name' => '首页第四行滚动内容',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '19',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '12',
      'introduce_length' => '100',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '4',
      'tagtemplate' => 'tag_content_i_pic3.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  29 => 
  array (
    'id' => '29',
    'name' => '首页第五行栏目说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'tagtemplate' => 'tag_category_lanmushuoming.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  30 => 
  array (
    'id' => 30,
    'name' => '首页第五行栏目6条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '12',
      'introduce_length' => '60',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '6',
      'tagtemplate' => 'tag_content_i_pic4.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  31 => 
  array (
    'id' => 31,
    'name' => '页底左侧栏目说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '1',
      'tagtemplate' => 'tag_category_lanmushuoming2.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  32 => 
  array (
    'id' => 32,
    'name' => '页底中间栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  33 => 
  array (
    'id' => '33',
    'name' => '页底中间栏目列表2条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '12',
      'introduce_length' => '40',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '2',
      'tagtemplate' => 'tag_content_dl_dt_dd.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  34 => 
  array (
    'id' => 34,
    'name' => '页底右侧栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '5',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
);